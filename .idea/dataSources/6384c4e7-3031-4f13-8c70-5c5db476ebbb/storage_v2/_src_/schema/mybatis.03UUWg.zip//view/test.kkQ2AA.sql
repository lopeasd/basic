create view test as
  select
    `mybatis`.`order`.`id`         AS `id`,
    `mybatis`.`order`.`user_id`    AS `user_id`,
    `mybatis`.`order`.`number`     AS `number`,
    `mybatis`.`order`.`createtime` AS `createtime`,
    `mybatis`.`order`.`note`       AS `note`
  from `mybatis`.`order`;

